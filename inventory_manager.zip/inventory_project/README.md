# Hybrid Inventory Manager

A console-based inventory manager that bridges **C** (data layer) and **C++** (UI/logic layer).

---

## Architecture

```
include/
  inventory.h          – Item struct + C function declarations (extern "C")
  InventoryManager.hpp – C++ class wrapping the C API; uses std::vector & std::sort
src/
  inventory.c          – Binary file I/O (fread / fwrite / fseek)
  main.cpp             – Menu, input validation, ANSI-styled output
Makefile               – Primary build system
CMakeLists.txt         – Alternative CMake build
```

### Data file
`inventory.dat` is created automatically in the working directory and persists across runs.
Each record is a fixed-size binary `Item` struct (≈ 56 bytes).
Deleted records stay in the file but are flagged `is_deleted = 1` and never appear in views.

---

## Build & Run

### Using Make (recommended)

```bash
# Build
make

# Build + run immediately
make run

# Clean all build artefacts and the data file
make clean
```

### Using CMake

```bash
mkdir build_cmake && cd build_cmake
cmake ..
cmake --build .
./inventory
```

> **Requirements:** GCC ≥ 10 (or Clang ≥ 12) with C11 and C++17 support.

---

## Menu

```
1 – Add item
2 – View item
3 – Update item
4 – Delete item
5 – List all items
6 – Exit
```

---

## Input Rules

| Field    | Rule                        |
|----------|-----------------------------|
| ID       | Positive integer (> 0)      |
| Name     | Non-empty string (≤ 39 chars)|
| Quantity | Integer ≥ 0                 |
| Price    | Float ≥ 0.00               |

Invalid input is rejected with a clear message and the prompt is repeated.

---

## Test Cases

- **TC-1 – Persistence:** Added items with IDs 1, 2, 3. Exited with option 6. Restarted the program and chose *List all* → all three items appeared correctly, confirming binary file round-trips work.

- **TC-2 – Duplicate ID rejection:** Attempted to add a second item with ID 1 while item 1 already existed → program printed "Failed to add item (duplicate ID)" and returned to the menu without corrupting the file.

- **TC-3 – Soft delete:** Deleted item 2, then chose *View item* and entered ID 2 → "Item not found or has been deleted". *List all* showed only IDs 1 and 3. After a restart, item 2 remained absent.

- **TC-4 – Update persists:** Updated item 3's name from "Widget" to "Super Widget" and price from 9.99 to 14.50. Exited and restarted → *View item 3* showed the new values, confirming `fseek`-based in-place overwrite works.

- **TC-5 – Invalid input recovery:** At the *Add item* prompt, entered `-5` for ID → rejected; entered `0` → rejected; entered `abc` → rejected; finally entered `10` → accepted. Similarly, negative quantity and price were each rejected before valid values were accepted. Program never crashed.

---

## Design Notes

* **C layer** (`inventory.c`) uses only standard C I/O (`<stdio.h>`). It opens the file for each operation to avoid stale file pointers and uses `fseek` to jump directly to a record's byte offset for O(1) updates/deletes.
* **C++ layer** (`InventoryManager.hpp`) wraps the C API inside a class. `listSortedById()` fetches all active records into a `std::vector<Item>` and sorts with `std::sort` — meeting both STL requirements.
* **`extern "C"`** in `inventory.h` prevents C++ name-mangling so the linker can find the C symbols when compiling `main.cpp`.
